﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace prog2_nie_obe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Figure fig;

        private bool brotating = false;

        private Point previousPoint = Point.Empty;

        private int scrollXLast = 0;

        private int scrollYLast = 0;

        private int scrollZLast = 0;

        private const int MOVEMENT_RATE = 5;

        private int forwardKey = 87;
        private int leftKey = 65;
        private int backKey = 83;
        private int rightKey = 68;
        private int upKey = 16;
        private int downKey = 17;

        private bool forwardDown = false;
        private bool backwardDown = false;

        private bool leftDown = false;
        private bool rightDown = false;

        private bool upDown = false;
        private bool downDown = false;

        private float camX = -5;
        private float camY = 0;
        private float camZ = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            GL.Enable(EnableCap.DepthTest);
            GL.MatrixMode(MatrixMode.Projection);

            Matrix4 projMat = Matrix4.CreatePerspectiveFieldOfView((float)Math.PI/2.0f, 1, 1, 100);
            //Matrix4 projMat = Matrix4.CreateOrthographic(20.0f, 20.0f, 0.0f, 100.0f);
            GL.LoadMatrix(ref projMat);

            Matrix4 lookat = Matrix4.LookAt(camX, camY, camZ, 0, 0, 0, 0, 1, 0);
            
            GL.MatrixMode(MatrixMode.Modelview);
            
            GL.LoadMatrix(ref lookat);
            
            fig = new Figure();

            fig.Load("C:\\Users\\Grant\\Academics\\Fall\\2017\\Graphics\\prog2_nie_obe\\nie_obe.wrl");

        }



        private void glControl1_Load(object sender, EventArgs e)
        {



        }

        private void glControl1_Click(object sender, EventArgs e)
        {
            GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            fig.Show();

            glControl1.SwapBuffers();

            //fig.rotateX(20);


        }

        

        private void glControl1_MouseDown(object sender, MouseEventArgs e)
        {
            brotating = true;

            previousPoint = e.Location;
        }

        private void glControl1_MouseUp(object sender, MouseEventArgs e)
        {
            brotating = false;
        }

        private void glControl1_MouseMove(object sender, MouseEventArgs e)
        {

            if (brotating)
            {
                double xRot = previousPoint.X - e.Location.X;

                double yRot = previousPoint.Y - e.Location.Y;
                
                GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

                GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

                fig.Show();

                GL.Rotate(1, yRot, xRot, 0);

                glControl1.SwapBuffers();
            }

            refreshPointerLoc(e.Location);

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

            GL.Rotate(trackBar1.Value - scrollXLast, 1, 0, 0);

            scrollXLast = trackBar1.Value;

            GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            fig.Show();

            glControl1.SwapBuffers();


        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {

            scrollYLast = trackBar1.Value;

            GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            fig.Show();

            GL.Rotate((trackBar3.Value - scrollYLast)/(2 * Math.PI), 0, 1, 0);
            
            glControl1.SwapBuffers();
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            GL.Rotate(trackBar2.Value - scrollZLast, 0, 0, 1);

            scrollZLast = trackBar1.Value;

            GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            fig.Show();

            glControl1.SwapBuffers();
        }

        private void refreshPointerLoc(Point loc)
        {

            txtPointerPos.Text = "(" + loc.X + "," + loc.Y + ")";
            txtPointerPos.Invalidate();
        }

        private void glControl1_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (this.forwardKey == e.KeyValue)
            {
                forwardDown = true;
            }
            else if (this.leftKey == e.KeyValue)
            {
                leftDown = true;
            }
            else if (this.rightKey == e.KeyValue)
            {
                rightDown = true;
            }
            else if (this.backKey == e.KeyValue)
            {
                backwardDown = true;
            }
            else if (this.upKey == e.KeyValue)
            {
                upDown = true;
            }
            else if (this.downKey == e.KeyValue)
            {
                downDown = true;
            }
        }


        /**
         * Update the current positioning and drawing of the environment
         */
        private void timer1_Tick(object sender, EventArgs e)
        {

            if (forwardDown)
                camX += MOVEMENT_RATE * (1.0f / timer1.Interval) ;
            if(leftDown)
                camZ -= MOVEMENT_RATE * (1.0f / timer1.Interval);
            if(rightDown)
                camZ += MOVEMENT_RATE * (1.0f / timer1.Interval);
            if(backwardDown)
                camX -= MOVEMENT_RATE * (1.0f / timer1.Interval);
            if(upDown)
                camY += MOVEMENT_RATE * (1.0f / timer1.Interval);
            if (downDown)
                camY -= MOVEMENT_RATE * (1.0f / timer1.Interval);



            Matrix4 lookat = Matrix4.LookAt(camX, camY, camZ, 0, 0, 0, 0, 1, 0);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadMatrix(ref lookat);

            GL.ClearColor(0.0f, 0.0f, 0.0f, 0.0f);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            fig.Show();

            glControl1.SwapBuffers();

            txtPointerPos.Text = "(" + camX + "," + camY + "," + camZ + ")";
            txtPointerPos.Invalidate();

        }

        private void glControl1_KeyUp(object sender, KeyEventArgs e)
        {

            if (this.forwardKey == e.KeyValue)
            {
                forwardDown = false;
            }
            else if (this.leftKey == e.KeyValue)
            {
                leftDown = false;
            }
            else if (this.rightKey == e.KeyValue)
            {
                rightDown = false;
            }
            else if (this.backKey == e.KeyValue)
            {
                backwardDown = false;
            }
            else if (this.upKey == e.KeyValue)
            {
                upDown = false;
            }
            else if (this.downKey == e.KeyValue)
            {
                downDown = false;
            }

        }
    }
}
